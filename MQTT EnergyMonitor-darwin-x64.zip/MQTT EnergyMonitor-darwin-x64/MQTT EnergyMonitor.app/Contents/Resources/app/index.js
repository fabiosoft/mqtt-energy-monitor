var mqtt = require('mqtt');
var notifier = require('node-notifier');
var lowerCase = require('lower-case');
const applescript = require('applescript');


//Customizations
var config = require('./config');

if( config.mqttHost.indexOf('127.0.0.1') > -1 || config.mqttHost.indexOf('localhost') > -1) {
    var aedes = require('aedes')()
    var server = require('net').createServer(aedes.handle)
    var port = config.port

    server.listen(port, function () {
    console.log('using local broker on port:', port)
    })
}

//Alert messages
var monoringIsActive = 'Monitor attivo'
var energyMissing = 'Mancanza di energia'
var energyMissingShutdownScheduledMessage = 'In corso spegnimento automatico.\nContinuare?'
var cancelActionLabel = 'No'
var continueWithShutdownLabel = 'Spegni tra 1 min!'
var retryMessage = 'Riprovo...'
var energyRestoredInTime = "Energia ripristinata in tempo"

var appName = "Energy Monitor"
var client = null
var isPowerOffCancelled = false

connectToMqtt()

function connectToMqtt() {
    client = mqtt.connect({
        host: config.mqttHost,
        port: config.port,
        username: config.username,
        password: config.password
    });

    client.on('message', function (topic, message, packet) {
        // console.log("message is "+ message);
        // console.log("topic is "+ topic);

        if (lowerCase(message) == config.lwtOnlineState) {
            isPowerOffCancelled = true
            notifier.notify({
                title: appName,
                message: energyRestoredInTime,
                sound: 'Funk',
                //wait: true,
                timeout: 5,
            })
        } else if (lowerCase(message) == config.lwtOfflineState) {
            isPowerOffCancelled = false
            showAlertNotification()
        }
    });

    client.on("connect", function () {
        //console.log("connected " + client.connected);

        var options = {
            retain: false,
            qos: 1
        };
        console.log("subscribing to topics");
        client.subscribe(config.powerMonitoringLWTTopic, options);

        notifier.notify({
            title: appName,
            message: monoringIsActive,
            timeout: 5
        });
    })

    client.on("error", function (error) {
        //console.log("Can't connect" + error);
        notifier.notify({
            title: appName,
            subtitle: error.message,
            message: retryMessage,
            timeout: 15
        });
        //setTimeout(connectToMqtt, 10*1000)
        //process.exit(1)
    });
}


// power off

function showAlertNotification() {
    notifier.notify({
        title: appName,
        subtitle: energyMissing,
        message: energyMissingShutdownScheduledMessage,
        sound: 'Funk',
        //wait: true,
        timeout: 5,
        closeLabel: cancelActionLabel,
        actions: continueWithShutdownLabel,
        //dropdownLabel: 'Scegli',
    },
        function (error, response) {

            let defaultDelay = config.secondsToDelay * 1000

            if (response == 'activate') {
                //console.log('activated')
                setTimeout(powerOff, defaultDelay)
            } else if (response == 'closed') {
                console.log("cancelled");
            } else if (response == 'timeout') {
                //console.log('timeout');
                setTimeout(powerOff, defaultDelay)
            } else {
                console.log("not recognized response = " + response)
            }
        }
    );
}

function powerOff() {
    if (isPowerOffCancelled == true) {
        console.log("poweroff cancelled");
        return; //in meantime energy is back 
    }
    console.log("sudo poweroff");

    const script = `tell application "System Events"
	set ProcNm_ to name of every application process whose visible is true
	repeat with i_ from 1 to count items of ProcNm_
		set TarProc_ to item i_ of ProcNm_
		try
			tell application TarProc_ to quit
		end try
	end repeat
	shut down
end tell`
    if (config.poweroffDebug == true) {
        notifier.notify({
            title: appName,
            message: 'Debug is active\nNow power off should be triggered...',
            sound: 'Funk',
            //wait: true,
            timeout: 30,
        })
    } else {
        applescript.execString(script, (err, rtn) => {
            if (err) {
                // Something went wrong!
            }
            if (Array.isArray(rtn)) {
                for (const songName of rtn) {
                    console.log(songName);
                }
            }
        })
    }
}