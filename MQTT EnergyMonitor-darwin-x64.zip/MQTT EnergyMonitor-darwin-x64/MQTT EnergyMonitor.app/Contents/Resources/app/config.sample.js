var config = {};

config.mqttHost = process.env.mqttHost || 'localhost' //'hassio.local'
config.port = process.env.port || 1883
config.username = process.env.username || ''
config.password = process.env.password || ''
config.powerMonitoringLWTTopic = process.env.powerMonitoringLWTTopic || "tele/energy/LWT";
config.lwtOnlineState = process.env.lwtOnlineState || 'online'
config.lwtOfflineState = process.env.lwtOfflineState || 'offline'
config.secondsToDelay = process.env.secondsToDelay || 60 //seconds to wait before issue the poweroff
config.poweroffDebug = process.env.poweroffDebug || true

module.exports = config;