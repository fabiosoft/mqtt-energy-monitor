const { app, Tray, Menu, BrowserWindow, ipcMain, dialog } = require('electron')
const shutdown = require('electron-shutdown-command');
const path = require('path')
var fs = require('fs');

const iconPath = path.join(__dirname, 'icon.png')
let tray = null
let mainWindow = null
var config = null
const userDataPath = app.getPath('userData');
const configFilePath = path.join(userDataPath, 'energyConfig' + '.json');

function createBrowserWindow() {
    mainWindow = new BrowserWindow({
        show: true,
        width: 1024,
        height: 768,
        icon: path.join(__dirname, 'assets/icons/mac/icon.icns')
    })
    if (process.platform == 'darwin') {
        app.dock.hide()
    }
    mainWindow.loadURL(`file://${__dirname}/index.html`)
    // mainWindow.webContents.openDevTools()
}

function createWindow() {
    createBrowserWindow()

    if (isConfigurationReady()) {
        mainWindow.hide()
    }

    tray = new Tray(iconPath)
    // tray.on('click', () => {
    //     if (mainWindow === null) {
    //         createBrowserWindow()
    //         mainWindow.show()
    //     }
    //     mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show()
    // })

    var contextMenu = Menu.buildFromTemplate([
        {
            label: 'Open',
            type: 'normal',
            click: openWindow
        },
        {
            label: 'Quit',
            type: 'normal',
            role: 'quit'
        }
    ])
    tray.setContextMenu(contextMenu)


    mainWindow.on('closed', function () {
        mainWindow = null
    })
}

function openWindow() {
    if (mainWindow === null) {
        createBrowserWindow()
        mainWindow.show()
    }
    mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show()
}

function killApp() {
    app.quit()
}

app.on('ready', function () {
    createWindow()
    console.log("configFile: " + configFilePath)

    if (isConfigurationReady()) {
        mainScript()
    }
})

function isConfigurationReady() {
    try {
        return fs.existsSync(configFilePath);
    } catch (err) {
        return false
    }
}

app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') {
        killApp()
    }
})

app.on('activate', function () {
    if (mainWindow === null) {
        createWindow()
    }
})

ipcMain.on('config:set', function (e, obj) {

    try {
        fs.writeFileSync(configFilePath, JSON.stringify(obj), 'utf-8');
        if (isConfigurationReady()) {
            config = JSON.parse(fs.readFileSync(configFilePath, 'utf8'));
            mainScript()
        }
    }
    catch (e) {
        //alert('Failed to save the file !');
        dialog.showErrorBox('Failed to save the config file!', e.message)
    }
})

ipcMain.on('asynchronous-message', (event, arg) => {
    console.log(arg) // prints "ping"
    event.sender.send('asynchronous-reply', 'pong')
})

ipcMain.on('synchronous-message', (event, arg) => {
    console.log(arg) // prints "ping"
    event.returnValue = 'pong'
})

// ---- MAIN SCRIPT ---

var mqtt = require('mqtt');
var notifier = require('node-notifier');
var lowerCase = require('lower-case');
if (process.platform == 'darwin') {
    const applescript = require('applescript');
}
var aedes = require('aedes')()
var server = require('net').createServer(aedes.handle)

//Alert messages
var monoringIsActive = 'Monitor attivo'
var energyMissing = 'Mancanza di energia'
var energyMissingShutdownScheduledMessage = 'In corso spegnimento automatico.\nContinuare?'
var cancelActionLabel = 'No'
var continueWithShutdownLabel = 'Spegni tra 1 min!'
var retryMessage = 'Riprovo...'
var energyRestoredInTime = "Energia ripristinata in tempo"

var appName = "Energy Monitor"
var client = null
var isPowerOffCancelled = false

function mainScript() {
    config = JSON.parse(fs.readFileSync(configFilePath, 'utf8'));
    if (config.mqttHost.indexOf('127.0.0.1') > -1 || config.mqttHost.indexOf('localhost') > -1) {

        var port = config.port
        server.close(function (err) {
            server.listen(port, function () {
                console.log('using local broker on port:', port)
                connectToMqtt()
            })
        })

    }

}

function connectToMqtt() {
    client = mqtt.connect({
        host: config.mqttHost,
        port: config.port,
        username: config.username,
        password: config.password
    });

    client.on('message', function (topic, message, packet) {
        console.log("message is " + message);
        console.log("topic is " + topic);

        if (lowerCase(message) == config.lwtOnlineState) {
            isPowerOffCancelled = true
            notifier.notify({
                title: appName,
                message: energyRestoredInTime,
                sound: 'Funk',
                //wait: true,
                timeout: 5,
            })
        } else if (lowerCase(message) == config.lwtOfflineState) {
            isPowerOffCancelled = false
            showAlertNotification()
        }
    });

    client.on("connect", function () {
        console.log("connected " + client.connected);

        var options = {
            retain: false,
            qos: 1
        };
        console.log("subscribing to topics");
        client.subscribe(config.powerMonitoringLWTTopic, options);

        notifier.notify({
            title: appName,
            message: monoringIsActive,
            timeout: 5
        });
    })

    client.on("error", function (error) {
        console.log("Can't connect" + error);
        notifier.notify({
            title: appName,
            subtitle: error.message,
            message: retryMessage,
            timeout: 15
        });
        //setTimeout(connectToMqtt, 10*1000)
        //process.exit(1)
    });
}


// power off

function showAlertNotification() {
    notifier.notify({
        title: appName,
        subtitle: energyMissing,
        message: energyMissingShutdownScheduledMessage,
        sound: 'Funk',
        //wait: true,
        timeout: 5,
        closeLabel: cancelActionLabel,
        actions: continueWithShutdownLabel,
        //dropdownLabel: 'Scegli',
    },
        function (error, response) {

            let defaultDelay = config.secondsToDelay * 1000

            if (response == 'activate') {
                //console.log('activated')
                setTimeout(powerOff, defaultDelay)
            } else if (response == 'closed') {
                console.log("cancelled");
            } else if (response == 'timeout') {
                //console.log('timeout');
                setTimeout(powerOff, defaultDelay)
            } else {
                console.log("not recognized response = " + response)
            }
        }
    );
}

function powerOff() {
    if (isPowerOffCancelled == true) {
        console.log("poweroff cancelled");
        return; //in meantime energy is back 
    }
    console.log("sudo poweroff");

    const script = `tell application "System Events"
	set ProcNm_ to name of every application process whose visible is true
	repeat with i_ from 1 to count items of ProcNm_
		set TarProc_ to item i_ of ProcNm_
		try
			tell application TarProc_ to quit
		end try
	end repeat
	shut down
end tell`
    if (config.poweroffDebug == true) {
        notifier.notify({
            title: appName,
            message: 'Debug is active\nNow power off should be triggered...',
            sound: 'Funk',
            //wait: true,
            timeout: 30,
        })
    } else {
        if (process.platform == 'darwin') {
            applescript.execString(script, (err, rtn) => {
                if (err) {
                    // Something went wrong!
                }
            })
        } else {
            //windows
            shutdown.shutdown({
                force: true,
                timerseconds: 1,
                sudo: true,
                debug: false,
                quitapp: true
            })
        }
    }
}