# mqtt-autoshutdown

Automation to automatically shutdown your system on MQTT message received from a power monitoring device via LWT, useful when your UPS is not power enough to supply power forever or withous easy calble/wireless interface.

## Use case

- Plug your embedded device monitor to a not protected power socket and connected to your mqtt broker or to your self hosted computer broker (use localhost in settings)
- Start this tool on startup
- On blackout, after notification, your system will be gracefully turned off.

##Setup

### Disclaimer 
Some issues and messy files, i just needed it to work quickly before next blackout, but i'm still working on it.

### Specs

- GUI made with ElectronJS.
- Full tested on Mac OS, work in progress for Windows.
